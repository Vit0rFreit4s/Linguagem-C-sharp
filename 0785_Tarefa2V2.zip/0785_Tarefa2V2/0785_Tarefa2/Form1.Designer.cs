﻿namespace _0785_Tarefa2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_hc = new System.Windows.Forms.Label();
            this.lbl_mc = new System.Windows.Forms.Label();
            this.lbl_situacao = new System.Windows.Forms.Label();
            this.btn_calcular = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.txt_hp = new System.Windows.Forms.TextBox();
            this.txt_mp = new System.Windows.Forms.TextBox();
            this.txt_md = new System.Windows.Forms.TextBox();
            this.txt_hd = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Partida";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Horas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(114, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Minutos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(114, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Minutos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Horas";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Duração";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(114, 281);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Minutos";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 281);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Horas";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(26, 248);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Chegada";
            // 
            // lbl_hc
            // 
            this.lbl_hc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_hc.Location = new System.Drawing.Point(26, 303);
            this.lbl_hc.Name = "lbl_hc";
            this.lbl_hc.Size = new System.Drawing.Size(35, 23);
            this.lbl_hc.TabIndex = 13;
            this.lbl_hc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_mc
            // 
            this.lbl_mc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_mc.Location = new System.Drawing.Point(115, 303);
            this.lbl_mc.Name = "lbl_mc";
            this.lbl_mc.Size = new System.Drawing.Size(35, 23);
            this.lbl_mc.TabIndex = 14;
            this.lbl_mc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_situacao
            // 
            this.lbl_situacao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_situacao.Location = new System.Drawing.Point(26, 359);
            this.lbl_situacao.Name = "lbl_situacao";
            this.lbl_situacao.Size = new System.Drawing.Size(330, 23);
            this.lbl_situacao.TabIndex = 15;
            this.lbl_situacao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_calcular
            // 
            this.btn_calcular.Location = new System.Drawing.Point(281, 262);
            this.btn_calcular.Name = "btn_calcular";
            this.btn_calcular.Size = new System.Drawing.Size(75, 23);
            this.btn_calcular.TabIndex = 16;
            this.btn_calcular.Text = "Calcular";
            this.btn_calcular.UseVisualStyleBackColor = true;
            this.btn_calcular.Click += new System.EventHandler(this.btn_calcular_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(281, 303);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 23);
            this.btn_clear.TabIndex = 17;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // txt_hp
            // 
            this.txt_hp.Location = new System.Drawing.Point(29, 83);
            this.txt_hp.MaxLength = 2;
            this.txt_hp.Name = "txt_hp";
            this.txt_hp.Size = new System.Drawing.Size(32, 20);
            this.txt_hp.TabIndex = 18;
            this.txt_hp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_hp.TextChanged += new System.EventHandler(this.txt_hp_TextChanged);
            this.txt_hp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_hp_KeyPress);
            // 
            // txt_mp
            // 
            this.txt_mp.Location = new System.Drawing.Point(117, 83);
            this.txt_mp.MaxLength = 2;
            this.txt_mp.Name = "txt_mp";
            this.txt_mp.Size = new System.Drawing.Size(32, 20);
            this.txt_mp.TabIndex = 19;
            this.txt_mp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_mp.TextChanged += new System.EventHandler(this.txt_mp_TextChanged);
            this.txt_mp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_mp_KeyPress);
            // 
            // txt_md
            // 
            this.txt_md.Location = new System.Drawing.Point(117, 198);
            this.txt_md.MaxLength = 2;
            this.txt_md.Name = "txt_md";
            this.txt_md.Size = new System.Drawing.Size(32, 20);
            this.txt_md.TabIndex = 21;
            this.txt_md.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_md.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_md_KeyPress);
            // 
            // txt_hd
            // 
            this.txt_hd.Location = new System.Drawing.Point(29, 198);
            this.txt_hd.MaxLength = 2;
            this.txt_hd.Name = "txt_hd";
            this.txt_hd.Size = new System.Drawing.Size(32, 20);
            this.txt_hd.TabIndex = 20;
            this.txt_hd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_hd.TextChanged += new System.EventHandler(this.txt_hd_TextChanged);
            this.txt_hd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_hd_KeyPress);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 402);
            this.Controls.Add(this.txt_md);
            this.Controls.Add(this.txt_hd);
            this.Controls.Add(this.txt_mp);
            this.Controls.Add(this.txt_hp);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_calcular);
            this.Controls.Add(this.lbl_situacao);
            this.Controls.Add(this.lbl_mc);
            this.Controls.Add(this.lbl_hc);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Compamhia Só Ida, Lda.";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_hc;
        private System.Windows.Forms.Label lbl_mc;
        private System.Windows.Forms.Label lbl_situacao;
        private System.Windows.Forms.Button btn_calcular;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.TextBox txt_hp;
        private System.Windows.Forms.TextBox txt_mp;
        private System.Windows.Forms.TextBox txt_md;
        private System.Windows.Forms.TextBox txt_hd;
    }
}

