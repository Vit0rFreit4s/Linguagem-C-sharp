﻿namespace _0785_App_03
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pic_inverno = new System.Windows.Forms.PictureBox();
            this.pic_outono = new System.Windows.Forms.PictureBox();
            this.pic_primavera = new System.Windows.Forms.PictureBox();
            this.pic_verao = new System.Windows.Forms.PictureBox();
            this.pic_canguru = new System.Windows.Forms.PictureBox();
            this.pic_suricato = new System.Windows.Forms.PictureBox();
            this.pic_ornitorrinco = new System.Windows.Forms.PictureBox();
            this.pic_tatu = new System.Windows.Forms.PictureBox();
            this.pic_atual = new System.Windows.Forms.PictureBox();
            this.lbl_atual = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.estaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.primaveraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outonoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invernoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.animaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.canguruToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ornitorrincoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suricatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tatuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rbt_play = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbt_stop = new System.Windows.Forms.RadioButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pic_inverno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_outono)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_primavera)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_verao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_canguru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_suricato)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_ornitorrinco)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_tatu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_atual)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pic_inverno
            // 
            this.pic_inverno.Image = global::_0785_App_03.Properties.Resources.inverno;
            this.pic_inverno.Location = new System.Drawing.Point(21, 36);
            this.pic_inverno.Name = "pic_inverno";
            this.pic_inverno.Size = new System.Drawing.Size(117, 75);
            this.pic_inverno.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_inverno.TabIndex = 0;
            this.pic_inverno.TabStop = false;
            this.pic_inverno.Click += new System.EventHandler(this.pic_inverno_Click);
            // 
            // pic_outono
            // 
            this.pic_outono.Image = global::_0785_App_03.Properties.Resources.outono;
            this.pic_outono.Location = new System.Drawing.Point(21, 117);
            this.pic_outono.Name = "pic_outono";
            this.pic_outono.Size = new System.Drawing.Size(117, 75);
            this.pic_outono.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_outono.TabIndex = 0;
            this.pic_outono.TabStop = false;
            this.pic_outono.Click += new System.EventHandler(this.pic_outono_Click);
            // 
            // pic_primavera
            // 
            this.pic_primavera.Image = global::_0785_App_03.Properties.Resources.primavera;
            this.pic_primavera.Location = new System.Drawing.Point(21, 198);
            this.pic_primavera.Name = "pic_primavera";
            this.pic_primavera.Size = new System.Drawing.Size(117, 75);
            this.pic_primavera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_primavera.TabIndex = 0;
            this.pic_primavera.TabStop = false;
            this.pic_primavera.Click += new System.EventHandler(this.pic_primavera_Click);
            // 
            // pic_verao
            // 
            this.pic_verao.Image = global::_0785_App_03.Properties.Resources.verao;
            this.pic_verao.Location = new System.Drawing.Point(21, 279);
            this.pic_verao.Name = "pic_verao";
            this.pic_verao.Size = new System.Drawing.Size(117, 75);
            this.pic_verao.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_verao.TabIndex = 0;
            this.pic_verao.TabStop = false;
            this.pic_verao.Click += new System.EventHandler(this.pic_verao_Click);
            // 
            // pic_canguru
            // 
            this.pic_canguru.Image = global::_0785_App_03.Properties.Resources.canguru;
            this.pic_canguru.Location = new System.Drawing.Point(159, 36);
            this.pic_canguru.Name = "pic_canguru";
            this.pic_canguru.Size = new System.Drawing.Size(117, 75);
            this.pic_canguru.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_canguru.TabIndex = 0;
            this.pic_canguru.TabStop = false;
            this.pic_canguru.Click += new System.EventHandler(this.pic_canguru_Click);
            // 
            // pic_suricato
            // 
            this.pic_suricato.Image = global::_0785_App_03.Properties.Resources.suricato;
            this.pic_suricato.Location = new System.Drawing.Point(159, 198);
            this.pic_suricato.Name = "pic_suricato";
            this.pic_suricato.Size = new System.Drawing.Size(117, 75);
            this.pic_suricato.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_suricato.TabIndex = 0;
            this.pic_suricato.TabStop = false;
            this.pic_suricato.Click += new System.EventHandler(this.pic_suricato_Click);
            // 
            // pic_ornitorrinco
            // 
            this.pic_ornitorrinco.Image = global::_0785_App_03.Properties.Resources.ornitorrinco;
            this.pic_ornitorrinco.Location = new System.Drawing.Point(159, 117);
            this.pic_ornitorrinco.Name = "pic_ornitorrinco";
            this.pic_ornitorrinco.Size = new System.Drawing.Size(117, 75);
            this.pic_ornitorrinco.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_ornitorrinco.TabIndex = 0;
            this.pic_ornitorrinco.TabStop = false;
            this.pic_ornitorrinco.Click += new System.EventHandler(this.pic_ornitorrinco_Click);
            // 
            // pic_tatu
            // 
            this.pic_tatu.Image = global::_0785_App_03.Properties.Resources.tatu;
            this.pic_tatu.Location = new System.Drawing.Point(159, 279);
            this.pic_tatu.Name = "pic_tatu";
            this.pic_tatu.Size = new System.Drawing.Size(117, 75);
            this.pic_tatu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_tatu.TabIndex = 0;
            this.pic_tatu.TabStop = false;
            this.pic_tatu.Click += new System.EventHandler(this.pic_tatu_Click);
            // 
            // pic_atual
            // 
            this.pic_atual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_atual.Location = new System.Drawing.Point(317, 36);
            this.pic_atual.Name = "pic_atual";
            this.pic_atual.Size = new System.Drawing.Size(301, 237);
            this.pic_atual.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_atual.TabIndex = 1;
            this.pic_atual.TabStop = false;
            // 
            // lbl_atual
            // 
            this.lbl_atual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_atual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_atual.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_atual.Location = new System.Drawing.Point(317, 279);
            this.lbl_atual.Name = "lbl_atual";
            this.lbl_atual.Size = new System.Drawing.Size(301, 26);
            this.lbl_atual.TabIndex = 2;
            this.lbl_atual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.estaçõesToolStripMenuItem,
            this.animaisToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(662, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // estaçõesToolStripMenuItem
            // 
            this.estaçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.primaveraToolStripMenuItem,
            this.verãoToolStripMenuItem,
            this.outonoToolStripMenuItem,
            this.invernoToolStripMenuItem});
            this.estaçõesToolStripMenuItem.Name = "estaçõesToolStripMenuItem";
            this.estaçõesToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.estaçõesToolStripMenuItem.Text = "Estações";
            // 
            // primaveraToolStripMenuItem
            // 
            this.primaveraToolStripMenuItem.Name = "primaveraToolStripMenuItem";
            this.primaveraToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.primaveraToolStripMenuItem.Text = "Primavera";
            this.primaveraToolStripMenuItem.Click += new System.EventHandler(this.primaveraToolStripMenuItem_Click);
            // 
            // verãoToolStripMenuItem
            // 
            this.verãoToolStripMenuItem.Name = "verãoToolStripMenuItem";
            this.verãoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.verãoToolStripMenuItem.Text = "Verão";
            this.verãoToolStripMenuItem.Click += new System.EventHandler(this.verãoToolStripMenuItem_Click);
            // 
            // outonoToolStripMenuItem
            // 
            this.outonoToolStripMenuItem.Name = "outonoToolStripMenuItem";
            this.outonoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.outonoToolStripMenuItem.Text = "Outono";
            this.outonoToolStripMenuItem.Click += new System.EventHandler(this.outonoToolStripMenuItem_Click);
            // 
            // invernoToolStripMenuItem
            // 
            this.invernoToolStripMenuItem.Name = "invernoToolStripMenuItem";
            this.invernoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.invernoToolStripMenuItem.Text = "Inverno";
            this.invernoToolStripMenuItem.Click += new System.EventHandler(this.invernoToolStripMenuItem_Click);
            // 
            // animaisToolStripMenuItem
            // 
            this.animaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.canguruToolStripMenuItem,
            this.ornitorrincoToolStripMenuItem,
            this.suricatoToolStripMenuItem,
            this.tatuToolStripMenuItem});
            this.animaisToolStripMenuItem.Name = "animaisToolStripMenuItem";
            this.animaisToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.animaisToolStripMenuItem.Text = "Animais";
            // 
            // canguruToolStripMenuItem
            // 
            this.canguruToolStripMenuItem.Name = "canguruToolStripMenuItem";
            this.canguruToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.canguruToolStripMenuItem.Text = "Canguru";
            this.canguruToolStripMenuItem.Click += new System.EventHandler(this.canguruToolStripMenuItem_Click);
            // 
            // ornitorrincoToolStripMenuItem
            // 
            this.ornitorrincoToolStripMenuItem.Name = "ornitorrincoToolStripMenuItem";
            this.ornitorrincoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ornitorrincoToolStripMenuItem.Text = "Ornitorrinco";
            this.ornitorrincoToolStripMenuItem.Click += new System.EventHandler(this.ornitorrincoToolStripMenuItem_Click);
            // 
            // suricatoToolStripMenuItem
            // 
            this.suricatoToolStripMenuItem.Name = "suricatoToolStripMenuItem";
            this.suricatoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.suricatoToolStripMenuItem.Text = "Suricato";
            this.suricatoToolStripMenuItem.Click += new System.EventHandler(this.suricatoToolStripMenuItem_Click);
            // 
            // tatuToolStripMenuItem
            // 
            this.tatuToolStripMenuItem.Name = "tatuToolStripMenuItem";
            this.tatuToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tatuToolStripMenuItem.Text = "Tatu";
            this.tatuToolStripMenuItem.Click += new System.EventHandler(this.tatuToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // rbt_play
            // 
            this.rbt_play.AutoSize = true;
            this.rbt_play.Location = new System.Drawing.Point(6, 19);
            this.rbt_play.Name = "rbt_play";
            this.rbt_play.Size = new System.Drawing.Size(45, 17);
            this.rbt_play.TabIndex = 4;
            this.rbt_play.TabStop = true;
            this.rbt_play.Text = "Play";
            this.rbt_play.UseVisualStyleBackColor = true;
            this.rbt_play.CheckedChanged += new System.EventHandler(this.rbt_play_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbt_stop);
            this.groupBox1.Controls.Add(this.rbt_play);
            this.groupBox1.Location = new System.Drawing.Point(317, 309);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(152, 47);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Slide Show";
            // 
            // rbt_stop
            // 
            this.rbt_stop.AutoSize = true;
            this.rbt_stop.Location = new System.Drawing.Point(66, 19);
            this.rbt_stop.Name = "rbt_stop";
            this.rbt_stop.Size = new System.Drawing.Size(47, 17);
            this.rbt_stop.TabIndex = 0;
            this.rbt_stop.TabStop = true;
            this.rbt_stop.Text = "Stop";
            this.rbt_stop.UseVisualStyleBackColor = true;
            this.rbt_stop.CheckedChanged += new System.EventHandler(this.rbt_stop_CheckedChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 368);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbl_atual);
            this.Controls.Add(this.pic_atual);
            this.Controls.Add(this.pic_tatu);
            this.Controls.Add(this.pic_verao);
            this.Controls.Add(this.pic_ornitorrinco);
            this.Controls.Add(this.pic_suricato);
            this.Controls.Add(this.pic_outono);
            this.Controls.Add(this.pic_canguru);
            this.Controls.Add(this.pic_primavera);
            this.Controls.Add(this.pic_inverno);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Estações do Ano e Animais";
            ((System.ComponentModel.ISupportInitialize)(this.pic_inverno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_outono)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_primavera)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_verao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_canguru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_suricato)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_ornitorrinco)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_tatu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_atual)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pic_inverno;
        private System.Windows.Forms.PictureBox pic_outono;
        private System.Windows.Forms.PictureBox pic_primavera;
        private System.Windows.Forms.PictureBox pic_verao;
        private System.Windows.Forms.PictureBox pic_canguru;
        private System.Windows.Forms.PictureBox pic_suricato;
        private System.Windows.Forms.PictureBox pic_ornitorrinco;
        private System.Windows.Forms.PictureBox pic_tatu;
        private System.Windows.Forms.PictureBox pic_atual;
        private System.Windows.Forms.Label lbl_atual;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem estaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem primaveraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outonoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invernoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem animaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem canguruToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ornitorrincoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suricatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tatuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.RadioButton rbt_play;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbt_stop;
        private System.Windows.Forms.Timer timer1;
    }
}

